package AULA.DESAFIO_01;

import java.awt.Graphics;
import java.awt.Graphics2D;

public class tileMap {
    Tiles pecaDoCenario;
    int[][] cenarioValido;
    int[][] cenario1DoJogo = {
        {0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
        {0,1,1,1,1,1,1,1,1,2,2,2,1,1,1,1},
        {0,1,1,1,1,1,1,1,1,2,2,2,1,1,0,0},
        {1,1,1,1,1,1,1,1,0,3,3,3,2,2,0,0},
        {0,1,0,0,1,1,1,1,1,3,3,3,3,1,0,0},
        {0,1,1,1,1,1,1,1,1,3,3,3,3,1,0,0},
        {0,1,1,1,1,3,3,2,2,2,2,1,1,1,0,0},
        {0,1,1,1,3,3,3,2,2,2,2,1,1,1,0,0},
        {0,1,1,1,1,1,1,1,0,3,3,3,2,2,0,0},
        {0,0,1,0,0,0,0,0,0,0,0,3,0,0,0,0}
    };

    int[][] cenario2DoJogo = {
        {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
        {0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
        {0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
        {0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
        {0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
        {0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
        {0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0},
        {0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
        {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
    };

    public tileMap() {
        this.cenarioValido = this.cenario1DoJogo;
        this.pecaDoCenario = new Tiles();
    }


    public void desenhar(Graphics d2) {
        int pecaDaMatriz;

        for(int lin = 0; lin < this.cenarioValido.length; lin++) {
            for(int col = 0; col < this.cenarioValido[0].length; col++) {

                pecaDaMatriz = cenarioValido[lin][col];

                this.pecaDoCenario.carregaPecaDaMatriz(pecaDaMatriz);
                this.pecaDoCenario.desenhaTile(d2, lin, col);
            }
        }
    }
}
