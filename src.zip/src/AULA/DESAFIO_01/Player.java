package AULA.DESAFIO_01;

import java.awt.Color;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;

import javax.swing.ImageIcon;

public class Player extends Rectangle {
	
	Image[]imgPlayerDown = new Image[3];
	Image[]imgPlayerRight = new Image[3];
	Image[]imgPlayerLeft = new Image[3];
	Image[]imgPlayerUp = new Image[3];
	
	private int frameJogador = 0;
	
	private Color CorFundo;
	private Image imagemPlayer;
	
	
	public Player() {
		this.x = 200;
		this.y = 100;
		this.width = 48;
		this.height = 48; 
		//ImageIcon icon;
		//icon = new ImageIcon("res/Players/down1.png");
		//this.imagemPlayer = icon.getImage();
		for (int i = 0; i < 3; i++) {
			this.imgPlayerDown[i] = new ImageIcon("res/Players/down" + (i+1) + ".png").getImage();
			this.imgPlayerRight[i] = new ImageIcon("res/Players/right" + (i+1) + ".png").getImage();
			this.imgPlayerLeft[i] = new ImageIcon("res/Players/left" + (i+1) + ".png").getImage();
			this.imgPlayerUp[i] = new ImageIcon("res/Players/up" + (i+1) + ".png").getImage();
		}
		this.imagemPlayer = this.imgPlayerDown[this.frameJogador];
		CorFundo = Color.WHITE;
	}
	
	public void DesenharPlayer(Graphics d2) {
		d2.setColor(this.CorFundo);
		//d2.fillRect(this.x, this.y, this.width, this.height);
		d2.drawImage(imagemPlayer, x, y, width, height, null);
	}
	
	public void atualizaPosicaoJogador(boolean ME, boolean MD, boolean MC, boolean MB) {
		if(ME) 	this.x -= 1;
		if(MD) 	this.x += 1;
		if(MC) 	this.y -= 1;
		if(MB) 	this.y += 1;
		this.atualizaSprite(ME, MC, MD, MB);
		
	}
	
	public void atualizaSprite(boolean moveEsq, boolean moveCima, boolean moveDir, boolean moveBaixo) {
		this.frameJogador++;
		if(moveEsq) {
			if(frameJogador >= this.imgPlayerLeft.length)
				frameJogador = 0;
			
			this.imagemPlayer = this.imgPlayerLeft[frameJogador];
		}
		if(moveDir) {
			if(frameJogador >= this.imgPlayerRight.length)
				frameJogador = 0;
			
			this.imagemPlayer = this.imgPlayerRight[frameJogador];
		}
		
		if(moveCima) {
			if(frameJogador >= this.imgPlayerUp.length)
				frameJogador = 0;
			
			this.imagemPlayer = this.imgPlayerUp[frameJogador];
		}
		
		if(moveBaixo) {
			if(frameJogador >= this.imgPlayerDown.length)
				frameJogador = 0;
			
			this.imagemPlayer = this.imgPlayerDown[frameJogador];
		}
	}
}
