package AULA.DESAFIO_01;

public class Principal {

	public static void main(String[] args) {
			System.out.println("Cap10-SPITES E TILES PARTE2");
			new Moldura();
	}

}
