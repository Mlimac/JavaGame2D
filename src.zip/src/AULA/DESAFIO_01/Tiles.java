package AULA.DESAFIO_01;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;

import javax.swing.ImageIcon;

public class Tiles  {
	private int posX, posY;
	private final int largura = 48, altura = 48;
	private String caminhoImg;
	private Image imgAtual;
	private Image imgGrass, imgSand, imgWall, imgWater;
	private Image imgWhite, imgGray;
	private boolean colisao;
	
	
	public Tiles() {
	    this.carregaImagemTile();
	}

public void desenhaTile(Graphics d2, int linha, int coluna) {
	this.posX = coluna * this.largura;
	this.posY = linha * this.altura;
	d2.drawImage(this.imgAtual, this.posX, this.posY, this.largura, this.altura, null);
	}

private void carregaImagemTile() {
	ImageIcon icon;
	icon = new ImageIcon("res/tiles/grass1.png");
	this.imgGrass = icon.getImage();
	icon = new ImageIcon("res/tiles/sand1.png");
	this.imgSand = icon.getImage();
	icon = new ImageIcon("res/tiles/water1.png");
	this.imgWater = icon.getImage();
	icon = new ImageIcon("res/tiles/wall1.png");
	this.imgWall = icon.getImage();
	icon = new ImageIcon("res/tiles/white.png");
	this.imgWhite = icon.getImage();
	icon = new ImageIcon("res/tiles/gray.png");
	this.imgGray = icon.getImage();
}

public void carregaPecaDaMatriz(int valorDaPeca) {
	if (valorDaPeca == 0) {
		this.imgAtual = this.imgWall;
		this.colisao= true; //não permite a passagem.
	}
	if (valorDaPeca == 1) {
		this.imgAtual = this.imgSand;
		this.colisao = false; // permite a passagem.
	}
	if (valorDaPeca == 2) {
		this.imgAtual = this.imgWater;
		this.colisao = true; //não permite a passagem.
	}
	if (valorDaPeca == 3) {
		this.imgAtual = this.imgGrass;
		this.colisao = false; // permite a passagem.
	}
	if (valorDaPeca == 4) {
		this.imgAtual = this.imgWhite;
		this.colisao = false; // permite a passagem.
	}
	if (valorDaPeca == 5) {
		this.imgAtual = this.imgGray;
		this.colisao = true; // permite a passagem.
	}
	//if (this.colisao == true) this.imgAtual = this.imgGray;
	//else this.imgAtual = this.imgWhite;

}

	public boolean isColisao() {
		return colisao;
	}
	public void setColisao(boolean colisao) {
		this.colisao = colisao;
	}

}
