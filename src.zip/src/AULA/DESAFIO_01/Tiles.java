package AULA.DESAFIO_01;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;

import javax.swing.ImageIcon;

public class Tiles  {
	private int posX, posY;
	private final int largura = 48, altura = 48;
	private String caminhoImg;
	private Image imgAtual;
	private Image imgGrass, imgSand, imgWall, imgWater;
	private Image imgWhite, imgGray;
	
	
	public Tiles() {
	    this.carregaImagemTile();
	}

public void desenhaTile(Graphics d2, int linha, int coluna) {
	this.posX = coluna * this.largura;
	this.posY = linha * this.altura;
	d2.drawImage(this.imgAtual, this.posX, this.posY, this.largura, this.altura, null);
	}

private void carregaImagemTile() {
	ImageIcon icon;
	icon = new ImageIcon("res/tiles/grass1.png");
	this.imgGrass = icon.getImage();
	icon = new ImageIcon("res/tiles/sand1.png");
	this.imgSand = icon.getImage();
	icon = new ImageIcon("res/tiles/water1.png");
	this.imgWater = icon.getImage();
	icon = new ImageIcon("res/tiles/wall1.png");
	this.imgWall = icon.getImage();
	icon = new ImageIcon("res/tiles/white1.png");
	this.imgWhite = icon.getImage();
	icon = new ImageIcon("res/tiles/gray1.png");
	this.imgGray = icon.getImage();
}

public void carregaPecaDaMatriz(int valorDaPeca) {
	if (valorDaPeca == 0) this.imgAtual = this.imgWall;
	if (valorDaPeca == 1) this.imgAtual = this.imgSand;
	if (valorDaPeca == 2) this.imgAtual = this.imgWater;
	if (valorDaPeca == 3) this.imgAtual = this.imgGrass;
	if (valorDaPeca == 4) this.imgAtual = this.imgWhite;
	if (valorDaPeca == 5) this.imgAtual = this.imgGray;
}

}
